package co.com.ejemplouno.demouno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoUnoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoUnoApplication.class, args);
	}

}
