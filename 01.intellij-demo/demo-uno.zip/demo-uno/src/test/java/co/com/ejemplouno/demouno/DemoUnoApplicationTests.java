package co.com.ejemplouno.demouno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoUnoApplicationTests {

	@Test
	void contextLoads() {
	}

}
